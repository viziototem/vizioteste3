import {
  User,
  Store,
  Product,
  Service,
  Ad,
  Banner,
  Category,
  Message,
  Conversation,
  ABMNews,
  ABMDocument,
  NotificationItem,
  StoreMetrics
} from '../types';

import heroAbmImg from '../assets/images/hero_abm_community_1790695743959.jpg';
import bannerGastronomyImg from '../assets/images/banner_gastronomy_1790695756555.jpg';
import bannerServicesImg from '../assets/images/banner_services_1790695767723.jpg';
import bannerWellnessImg from '../assets/images/banner_wellness_1790695778361.jpg';

const STORAGE_KEYS = {
  CURRENT_USER: 'abm_current_user',
  AUTHENTICATED: 'abm_authenticated',
  PREVIEW_STARTED_AT: 'abm_preview_started_at',
  PREVIEW_LOCKED: 'abm_preview_locked',
  USERS: 'abm_users',
  STORES: 'abm_stores',
  PRODUCTS: 'abm_products',
  SERVICES: 'abm_services',
  ADS: 'abm_ads',
  BANNERS: 'abm_banners',
  CATEGORIES: 'abm_categories',
  CONVERSATIONS: 'abm_conversations',
  MESSAGES: 'abm_messages',
  NEWS: 'abm_news',
  DOCUMENTS: 'abm_documents',
  NOTIFICATIONS: 'abm_notifications',
  FAVORITES: 'abm_favorites',
  DATA_VERSION: 'abm_data_version',
};

// Initial Seed Users
export const SEED_USERS: User[] = [];

// Initial Seed Categories
export const SEED_CATEGORIES: Category[] = [];

// Initial Seed Stores
export const SEED_STORES: Store[] = [];

// Initial Seed Products
export const SEED_PRODUCTS: Product[] = [];

// Initial Seed Services
export const SEED_SERVICES: Service[] = [];

// Initial Seed Ads
export const SEED_ADS: Ad[] = [];

// Initial Seed Banners
export const SEED_BANNERS: Banner[] = [];

// Initial Seed ABM News
export const SEED_NEWS: ABMNews[] = [];

// Initial Seed Documents
export const SEED_DOCUMENTS: ABMDocument[] = [];

// Initial Seed Conversations
export const SEED_CONVERSATIONS: Conversation[] = [];

// Initial Seed Messages
export const SEED_MESSAGES: Message[] = [];

// Initial Seed Notifications
export const SEED_NOTIFICATIONS: NotificationItem[] = [];

class DataStore {
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.initialize();
  }

  private initialize() {
    // Production starts completely empty. A versioned reset removes data from the previous demo build once.
    const PRODUCTION_DATA_VERSION = 'production-v1';
    const currentVersion = localStorage.getItem(STORAGE_KEYS.DATA_VERSION);

    if (currentVersion !== PRODUCTION_DATA_VERSION) {
      [
        STORAGE_KEYS.CURRENT_USER,
        STORAGE_KEYS.AUTHENTICATED,
        STORAGE_KEYS.PREVIEW_STARTED_AT,
        STORAGE_KEYS.PREVIEW_LOCKED,
        STORAGE_KEYS.USERS,
        STORAGE_KEYS.STORES,
        STORAGE_KEYS.PRODUCTS,
        STORAGE_KEYS.SERVICES,
        STORAGE_KEYS.ADS,
        STORAGE_KEYS.BANNERS,
        STORAGE_KEYS.CATEGORIES,
        STORAGE_KEYS.CONVERSATIONS,
        STORAGE_KEYS.MESSAGES,
        STORAGE_KEYS.NEWS,
        STORAGE_KEYS.DOCUMENTS,
        STORAGE_KEYS.NOTIFICATIONS,
        STORAGE_KEYS.FAVORITES,
      ].forEach((key) => localStorage.removeItem(key));
      localStorage.setItem(STORAGE_KEYS.DATA_VERSION, PRODUCTION_DATA_VERSION);
    }

    const emptyCollections: Array<[string, unknown[]]> = [
      [STORAGE_KEYS.USERS, SEED_USERS],
      [STORAGE_KEYS.STORES, SEED_STORES],
      [STORAGE_KEYS.PRODUCTS, SEED_PRODUCTS],
      [STORAGE_KEYS.SERVICES, SEED_SERVICES],
      [STORAGE_KEYS.ADS, SEED_ADS],
      [STORAGE_KEYS.BANNERS, SEED_BANNERS],
      [STORAGE_KEYS.CATEGORIES, SEED_CATEGORIES],
      [STORAGE_KEYS.CONVERSATIONS, SEED_CONVERSATIONS],
      [STORAGE_KEYS.MESSAGES, SEED_MESSAGES],
      [STORAGE_KEYS.NEWS, SEED_NEWS],
      [STORAGE_KEYS.DOCUMENTS, SEED_DOCUMENTS],
      [STORAGE_KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS],
      [STORAGE_KEYS.FAVORITES, []],
    ];

    emptyCollections.forEach(([key, value]) => {
      if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(value));
    });

    if (!localStorage.getItem(STORAGE_KEYS.AUTHENTICATED)) {
      localStorage.setItem(STORAGE_KEYS.AUTHENTICATED, 'false');
    }
  }

  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => listener());
  }

  // --- Auth & Users ---
  public getCurrentUser(): User {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      }
    }
    return {
      id: '', name: '', email: '', phone: '', avatar: '', role: 'resident', status: 'pending', createdAt: ''
    };
  }

  public isAuthenticated(): boolean {
    return localStorage.getItem(STORAGE_KEYS.AUTHENTICATED) === 'true';
  }

  public setCurrentUser(user: User) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    localStorage.setItem(STORAGE_KEYS.AUTHENTICATED, 'true');
    localStorage.removeItem(STORAGE_KEYS.PREVIEW_LOCKED);
    localStorage.removeItem(STORAGE_KEYS.PREVIEW_STARTED_AT);
    this.notify();
  }

  public logout() {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.setItem(STORAGE_KEYS.AUTHENTICATED, 'false');
    localStorage.removeItem(STORAGE_KEYS.PREVIEW_STARTED_AT);
    localStorage.removeItem(STORAGE_KEYS.PREVIEW_LOCKED);
    this.notify();
  }

  public getPreviewStartedAt(): number | null {
    const raw = localStorage.getItem(STORAGE_KEYS.PREVIEW_STARTED_AT);
    return raw ? Number(raw) : null;
  }

  public ensurePreviewStarted(): number {
    const existing = this.getPreviewStartedAt();
    if (existing) return existing;
    const started = Date.now();
    localStorage.setItem(STORAGE_KEYS.PREVIEW_STARTED_AT, String(started));
    return started;
  }

  public isPreviewLocked(): boolean {
    return localStorage.getItem(STORAGE_KEYS.PREVIEW_LOCKED) === 'true';
  }

  public lockPreview() {
    localStorage.setItem(STORAGE_KEYS.PREVIEW_LOCKED, 'true');
    this.notify();
  }

  public getUsers(): User[] {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    return raw ? JSON.parse(raw) : [];
  }

  public addUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const users = this.getUsers();
    const newUser: User = {
      ...user,
      id: `user_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.notify();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<User>): User | null {
    const users = this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) return null;
    users[index] = { ...users[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    
    // If updating current user, sync current session
    const current = this.getCurrentUser();
    if (current && current.id === id) {
      this.setCurrentUser(users[index]);
    } else {
      this.notify();
    }
    return users[index];
  }

  // --- Stores ---
  public getStores(): Store[] {
    const raw = localStorage.getItem(STORAGE_KEYS.STORES);
    return raw ? JSON.parse(raw) : [];
  }

  public getStoreById(id: string): Store | undefined {
    return this.getStores().find((s) => s.id === id);
  }

  public addStore(store: Omit<Store, 'id' | 'createdAt' | 'rating' | 'reviewCount'>): Store {
    const stores = this.getStores();
    const newStore: Store = {
      ...store,
      id: `store_${Date.now()}`,
      rating: 5.0,
      reviewCount: 1,
      createdAt: new Date().toISOString(),
    };
    stores.push(newStore);
    localStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(stores));
    this.notify();
    return newStore;
  }

  public updateStore(id: string, updates: Partial<Store>): Store | null {
    const stores = this.getStores();
    const index = stores.findIndex((s) => s.id === id);
    if (index === -1) return null;
    stores[index] = { ...stores[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(stores));
    this.notify();
    return stores[index];
  }

  public deleteStore(id: string): boolean {
    let stores = this.getStores();
    stores = stores.filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(stores));
    this.notify();
    return true;
  }

  // --- Products & Services ---
  public getProducts(storeId?: string): Product[] {
    const raw = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    const list: Product[] = raw ? JSON.parse(raw) : [];
    return storeId ? list.filter((p) => p.storeId === storeId) : list;
  }

  public addProduct(product: Omit<Product, 'id' | 'createdAt'>): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...product,
      id: `prod_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    products.push(newProduct);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
    return newProduct;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === id);
    if (index === -1) return null;
    products[index] = { ...products[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
    return products[index];
  }

  public deleteProduct(id: string): boolean {
    let products = this.getProducts();
    products = products.filter((p) => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
    return true;
  }

  public getServices(storeId?: string): Service[] {
    const raw = localStorage.getItem(STORAGE_KEYS.SERVICES);
    const list: Service[] = raw ? JSON.parse(raw) : [];
    return storeId ? list.filter((s) => s.storeId === storeId) : list;
  }

  public addService(service: Omit<Service, 'id' | 'createdAt'>): Service {
    const services = this.getServices();
    const newService: Service = {
      ...service,
      id: `serv_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    services.push(newService);
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(services));
    this.notify();
    return newService;
  }

  public updateService(id: string, updates: Partial<Service>): Service | null {
    const services = this.getServices();
    const index = services.findIndex((s) => s.id === id);
    if (index === -1) return null;
    services[index] = { ...services[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(services));
    this.notify();
    return services[index];
  }

  public deleteService(id: string): boolean {
    let services = this.getServices();
    services = services.filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(services));
    this.notify();
    return true;
  }

  // --- Ads ---
  public getAds(storeId?: string): Ad[] {
    const raw = localStorage.getItem(STORAGE_KEYS.ADS);
    const list: Ad[] = raw ? JSON.parse(raw) : [];
    return storeId ? list.filter((a) => a.storeId === storeId) : list;
  }

  public addAd(ad: Omit<Ad, 'id' | 'createdAt' | 'viewsCount' | 'clicksCount'>): Ad {
    const ads = this.getAds();
    const newAd: Ad = {
      ...ad,
      id: `ad_${Date.now()}`,
      viewsCount: 1,
      clicksCount: 0,
      createdAt: new Date().toISOString(),
    };
    ads.push(newAd);
    localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(ads));
    this.notify();
    return newAd;
  }

  public updateAd(id: string, updates: Partial<Ad>): Ad | null {
    const ads = this.getAds();
    const index = ads.findIndex((a) => a.id === id);
    if (index === -1) return null;
    ads[index] = { ...ads[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(ads));
    this.notify();
    return ads[index];
  }

  public deleteAd(id: string): boolean {
    let ads = this.getAds();
    ads = ads.filter((a) => a.id !== id);
    localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(ads));
    this.notify();
    return true;
  }

  public recordAdClick(id: string) {
    const ads = this.getAds();
    const ad = ads.find((a) => a.id === id);
    if (ad) {
      ad.clicksCount += 1;
      localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(ads));
      this.notify();
    }
  }

  // --- Banners ---
  public getBanners(): Banner[] {
    const raw = localStorage.getItem(STORAGE_KEYS.BANNERS);
    return raw ? JSON.parse(raw) : [];
  }

  public addBanner(banner: Omit<Banner, 'id' | 'createdAt'>): Banner {
    const banners = this.getBanners();
    const newBanner: Banner = {
      ...banner,
      id: `banner_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    banners.push(newBanner);
    localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
    this.notify();
    return newBanner;
  }

  public updateBanner(id: string, updates: Partial<Banner>): Banner | null {
    const banners = this.getBanners();
    const index = banners.findIndex((b) => b.id === id);
    if (index === -1) return null;
    banners[index] = { ...banners[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
    this.notify();
    return banners[index];
  }

  public deleteBanner(id: string): boolean {
    let banners = this.getBanners();
    banners = banners.filter((b) => b.id !== id);
    localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
    this.notify();
    return true;
  }

  // --- Categories ---
  public getCategories(): Category[] {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return raw ? JSON.parse(raw) : [];
  }

  // --- News & Documents ---
  public getNews(): ABMNews[] {
    const raw = localStorage.getItem(STORAGE_KEYS.NEWS);
    return raw ? JSON.parse(raw) : [];
  }

  public addNews(news: Omit<ABMNews, 'id'>): ABMNews {
    const list = this.getNews();
    const item: ABMNews = {
      ...news,
      id: `news_${Date.now()}`,
    };
    list.unshift(item);
    localStorage.setItem(STORAGE_KEYS.NEWS, JSON.stringify(list));
    this.notify();
    return item;
  }

  public getDocuments(): ABMDocument[] {
    const raw = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
    return raw ? JSON.parse(raw) : [];
  }

  // --- Conversations & Messages ---
  public getConversations(userId?: string): Conversation[] {
    const raw = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
    const list: Conversation[] = raw ? JSON.parse(raw) : [];
    if (!userId) return list;
    return list.filter((c) => c.participantIds.includes(userId));
  }

  public getConversationById(id: string): Conversation | undefined {
    return this.getConversations().find((c) => c.id === id);
  }

  public getMessages(conversationId: string): Message[] {
    const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    const list: Message[] = raw ? JSON.parse(raw) : [];
    return list.filter((m) => m.conversationId === conversationId);
  }

  public sendMessage(conversationId: string, senderId: string, senderName: string, senderRole: User['role'], receiverId: string, text: string, attachment?: string): Message {
    const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    const list: Message[] = raw ? JSON.parse(raw) : [];
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId,
      senderName,
      senderRole,
      receiverId,
      message: text,
      attachment,
      createdAt: new Date().toISOString(),
    };
    list.push(newMsg);
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(list));

    // Update conversation last message
    const convs = this.getConversations();
    const convIndex = convs.findIndex((c) => c.id === conversationId);
    if (convIndex !== -1) {
      convs[convIndex].lastMessage = text;
      convs[convIndex].lastMessageAt = 'Agora';
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(convs));
    }

    this.notify();
    return newMsg;
  }

  public createConversation(
    type: 'resident_abm' | 'resident_merchant',
    resident: User,
    otherParty: { id: string; name: string; avatar: string; role: User['role']; storeId?: string },
    initialMessage?: string,
    title?: string,
    subtitle?: string
  ): Conversation {
    const convs = this.getConversations();
    const existing = convs.find(
      (c) => c.type === type && c.participantIds.includes(resident.id) && c.participantIds.includes(otherParty.id)
    );
    if (existing) {
      if (initialMessage) {
        this.sendMessage(existing.id, resident.id, resident.name, resident.role, otherParty.id, initialMessage);
      }
      return existing;
    }

    const newConv: Conversation = {
      id: `conv_${Date.now()}`,
      type,
      participantIds: [resident.id, otherParty.id],
      participantNames: {
        [resident.id]: resident.name,
        [otherParty.id]: otherParty.name,
      },
      participantRoles: {
        [resident.id]: resident.role,
        [otherParty.id]: otherParty.role,
      },
      participantAvatars: {
        [resident.id]: resident.avatar,
        [otherParty.id]: otherParty.avatar,
      },
      storeId: otherParty.storeId,
      title: title || (type === 'resident_abm' ? 'Atendimento ABM' : otherParty.name),
      subtitle: subtitle || (type === 'resident_abm' ? 'Canal Oficial do Morador' : 'Conversa Direta'),
      lastMessage: initialMessage || 'Conversa iniciada',
      lastMessageAt: 'Agora',
      unreadCounts: {
        [resident.id]: 0,
        [otherParty.id]: 1,
        user_master_admin: 0,
      },
      status: 'open',
    };

    convs.unshift(newConv);
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(convs));

    if (initialMessage) {
      this.sendMessage(newConv.id, resident.id, resident.name, resident.role, otherParty.id, initialMessage);
    }

    this.notify();
    return newConv;
  }

  // --- Favorites ---
  public getFavorites(): string[] {
    const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    return raw ? JSON.parse(raw) : [];
  }

  public toggleFavorite(id: string): boolean {
    let favs = this.getFavorites();
    const exists = favs.includes(id);
    if (exists) {
      favs = favs.filter((item) => item !== id);
    } else {
      favs.push(id);
    }
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favs));
    this.notify();
    return !exists;
  }

  public isFavorite(id: string): boolean {
    return this.getFavorites().includes(id);
  }

  // --- Notifications ---
  public getNotifications(userId?: string): NotificationItem[] {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    const list: NotificationItem[] = raw ? JSON.parse(raw) : [];
    return userId ? list.filter((n) => n.userId === userId) : list;
  }

  public markNotificationAsRead(id: string) {
    const list = this.getNotifications();
    const item = list.find((n) => n.id === id);
    if (item) {
      item.read = true;
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(list));
      this.notify();
    }
  }

  // --- Merchant & Admin Metrics ---
  public getStoreMetrics(storeId: string): StoreMetrics {
    const ads = this.getAds(storeId);
    const totalAdViews = ads.reduce((acc, curr) => acc + curr.viewsCount, 0);
    const totalAdClicks = ads.reduce((acc, curr) => acc + curr.clicksCount, 0);

    return {
      storeViews: 520 + totalAdViews,
      adViews: totalAdViews || 384,
      whatsappClicks: 140 + totalAdClicks,
      phoneClicks: 42,
      locationClicks: 65,
      favorites: 48,
    };
  }

  public getAdminMetrics() {
    const stores = this.getStores();
    const users = this.getUsers();
    const ads = this.getAds();
    const convs = this.getConversations();

    const residentsCount = users.filter((u) => u.role === 'resident').length;
    const merchantsCount = users.filter((u) => u.role === 'merchant').length;
    const activeStores = stores.filter((s) => s.status === 'active').length;
    const activeAds = ads.filter((a) => a.status === 'active').length;

    return {
      residentsCount,
      merchantsCount,
      activeStores,
      activeAds,
      totalViews: 14890,
      openConversations: convs.filter((c) => c.status !== 'resolved').length,
      newRegistrationsMonth: 34,
      whatsappLeads: 620,
    };
  }

  // Reset to default seed
  public resetToDefault() {
    localStorage.clear();
    this.initialize();
    this.notify();
  }
}

export const dataStore = new DataStore();
