import React, { useState } from 'react';
import { dataStore } from '../../services/store';
import { User } from '../../types';
import { X, Mail, Lock, Phone, User as UserIcon, Eye, EyeOff, ArrowLeft, Chrome, Apple, Facebook, ShieldCheck, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
  locked?: boolean;
  initialMode?: 'login' | 'register';
}

type AuthView = 'gate' | 'login' | 'register' | 'phone' | 'forgot';

const DEFAULT_AVATAR = '';

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess, locked = false, initialMode = 'login' }) => {
  const [view, setView] = useState<AuthView>(locked ? 'gate' : initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regUnit, setRegUnit] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  if (!isOpen) return null;

  const resetMessages = () => { setErrorMessage(''); setSuccessMessage(''); };

  const authenticate = (user: User) => {
    dataStore.setCurrentUser(user);
    onSuccess(user);
    onClose();
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault(); resetMessages();
    const found = dataStore.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!found) {
      setErrorMessage('E-mail não localizado. Confira seus dados ou escolha uma das opções de acesso abaixo.');
      return;
    }
    if (password.length < 1) {
      setErrorMessage('Digite sua senha para continuar.');
      return;
    }
    authenticate(found);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault(); resetMessages();
    if (!regName || !regEmail || !regPhone || !regUnit || !regPassword || !regConfirm) {
      setErrorMessage('Preencha todos os campos obrigatórios.');
      return;
    }
    if (regPassword.length < 6) {
      setErrorMessage('A senha precisa ter pelo menos 6 caracteres.');
      return;
    }
    if (regPassword !== regConfirm) {
      setErrorMessage('As senhas não coincidem.');
      return;
    }
    if (dataStore.getUsers().some(u => u.email.toLowerCase() === regEmail.toLowerCase().trim())) {
      setErrorMessage('Este e-mail já está cadastrado.');
      return;
    }
    const newUser = dataStore.addUser({
      name: regName.trim(),
      email: regEmail.trim(),
      phone: regPhone.trim(),
      unit: regUnit.trim(),
      role: 'resident',
      status: 'active',
      avatar: DEFAULT_AVATAR,
    });
    authenticate(newUser);
  };

  const handleSocial = (provider: string) => {
    resetMessages();
    setErrorMessage(`Login com ${provider} precisa ser conectado ao provedor OAuth do projeto. Nenhuma conta de demonstração será criada.`);
  };

  const handlePhone = (e: React.FormEvent) => {
    e.preventDefault(); resetMessages();
    if (!phone || code.length < 4) {
      setErrorMessage('Informe o telefone e o código recebido.');
      return;
    }
    const found = dataStore.getUsers().find(u => u.phone.replace(/\D/g, '') === phone.replace(/\D/g, ''));
    if (!found) {
      setErrorMessage('Telefone não localizado. Faça seu cadastro ou use uma conta já cadastrada.');
      return;
    }
    authenticate(found);
  };

  const shell = (children: React.ReactNode) => (
    <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-800 rounded-[24px] w-full max-w-[420px] shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
        {!locked && (
          <button onClick={onClose} className="absolute mt-4 ml-[calc(100%-56px)] p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 z-10">
            <X className="w-5 h-5" />
          </button>
        )}
        {children}
      </div>
    </div>
  );

  const header = (title: string, subtitle: string) => (
    <div className="text-center px-7 pt-7 pb-4">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-black text-xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-600/20">A</div>
      <h2 className="mt-3 text-xl font-black text-slate-900 dark:text-white">{title}</h2>
      <p className="mt-1 text-xs leading-relaxed text-slate-500">{subtitle}</p>
    </div>
  );

  const errorBox = errorMessage && <div className="mx-6 mb-3 p-2.5 rounded-xl bg-rose-50 text-rose-700 text-xs flex gap-2"><AlertCircle className="w-4 h-4 shrink-0" /><span>{errorMessage}</span></div>;
  const successBox = successMessage && <div className="mx-6 mb-3 p-2.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs flex gap-2"><CheckCircle2 className="w-4 h-4 shrink-0" /><span>{successMessage}</span></div>;

  if (view === 'gate') return shell(
    <div className="px-7 py-9 text-center">
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-black text-2xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-600/20">A</div>
      <h2 className="mt-5 text-2xl font-black text-slate-900 dark:text-white">Faça parte da ABM em Todo Lugar</h2>
      <p className="mt-2 text-sm leading-relaxed text-slate-500">Tenha acesso completo a lojas, serviços, ofertas, informações e benefícios da sua comunidade.</p>
      <div className="mt-6 space-y-2.5">
        <button onClick={() => setView('login')} className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl">Entrar na minha conta</button>
        <button onClick={() => setView('register')} className="w-full py-3.5 border border-emerald-200 text-emerald-700 hover:bg-emerald-50 font-bold rounded-xl">Criar conta grátis</button>
      </div>
      <p className="mt-4 text-[11px] text-slate-400">É gratuito para moradores.</p>
    </div>
  );

  if (view === 'register') return shell(<>
    {header('Crie sua conta gratuitamente', 'Tenha acesso completo a lojas, serviços, ofertas, informações e benefícios da sua comunidade.')}
    {errorBox}
    <form onSubmit={handleRegister} className="px-6 pb-6 space-y-2.5 text-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <input value={regName} onChange={e => setRegName(e.target.value)} placeholder="Nome completo *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
        <input value={regPhone} onChange={e => setRegPhone(e.target.value)} placeholder="Telefone / WhatsApp *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      </div>
      <input type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} placeholder="E-mail *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <input value={regUnit} onChange={e => setRegUnit(e.target.value)} placeholder="Condomínio e unidade *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <input type={showPassword ? 'text' : 'password'} value={regPassword} onChange={e => setRegPassword(e.target.value)} placeholder="Senha *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <input type={showPassword ? 'text' : 'password'} value={regConfirm} onChange={e => setRegConfirm(e.target.value)} placeholder="Confirmar senha *" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <label className="flex items-center gap-2 text-[11px] text-slate-500"><input type="checkbox" required /> Aceito os termos de uso e a política de privacidade.</label>
      <button className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-sm">Criar minha conta</button>
      <SocialButtons onSelect={handleSocial} />
      <button type="button" onClick={() => { resetMessages(); setView('login'); }} className="w-full text-xs font-bold text-emerald-700">Já tenho uma conta</button>
    </form>
  </>);

  if (view === 'phone') return shell(<>
    {header('Entrar com telefone', 'Receba um código de acesso por SMS ou WhatsApp.')}
    {errorBox}{successBox}
    <form onSubmit={handlePhone} className="px-6 pb-7 space-y-3 text-xs">
      <div className="relative"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input value={phone} onChange={e => setPhone(e.target.value)} placeholder="(21) 99999-8888" className="w-full pl-9 p-3 bg-slate-50 rounded-xl border border-slate-200" /></div>
      <button type="button" onClick={() => setSuccessMessage('Solicitação de código enviada. Conecte o serviço de SMS/WhatsApp no backend para gerar e validar o código.')} className="w-full py-2.5 rounded-xl border border-slate-200 font-bold">Enviar código</button>
      <input value={code} onChange={e => setCode(e.target.value)} placeholder="Código recebido" inputMode="numeric" className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <button className="w-full py-3 bg-emerald-600 text-white font-bold rounded-xl">Continuar</button>
      <button type="button" onClick={() => setView('login')} className="w-full text-xs font-bold text-slate-500">Voltar</button>
    </form>
  </>);

  if (view === 'forgot') return shell(<>
    {header('Recuperar acesso', 'Informe seu e-mail e enviaremos as instruções para redefinir sua senha.')}
    {errorBox}{successBox}
    <form onSubmit={e => { e.preventDefault(); resetMessages(); setSuccessMessage('Se o e-mail estiver cadastrado, as instruções de recuperação serão enviadas.'); }} className="px-6 pb-7 space-y-3">
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="seu@email.com" required className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200" />
      <button className="w-full py-3 bg-emerald-600 text-white font-bold rounded-xl">Enviar instruções</button>
      <button type="button" onClick={() => setView('login')} className="w-full text-xs font-bold text-slate-500">Voltar para login</button>
    </form>
  </>);

  return shell(<>
    {header('Entrar na ABM em Todo Lugar', 'Acesse sua conta para liberar todos os recursos da plataforma.')}
    {errorBox}
    <form onSubmit={handleLogin} className="px-6 pb-6 space-y-3 text-xs">
      <div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="seu@email.com" required className="w-full pl-9 p-3 bg-slate-50 rounded-xl border border-slate-200" /></div>
      <div className="relative"><Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Senha" required className="w-full pl-9 pr-10 p-3 bg-slate-50 rounded-xl border border-slate-200" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">{showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div>
      <button className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl">Entrar na minha conta</button>
      <button type="button" onClick={() => setView('forgot')} className="w-full text-xs text-emerald-700 font-semibold">Esqueci minha senha</button>
      <div className="relative py-1"><div className="border-t border-slate-100" /><span className="absolute left-1/2 -translate-x-1/2 -top-2 bg-white px-3 text-[10px] text-slate-400">OU</span></div>
      <SocialButtons onSelect={handleSocial} />
      <button type="button" onClick={() => setView('phone')} className="w-full py-2.5 rounded-xl border border-slate-200 font-bold flex items-center justify-center gap-2"><Phone className="w-4 h-4" /> Continuar com telefone</button>
      <button type="button" onClick={() => setView('register')} className="w-full pt-1 text-xs font-bold text-emerald-700">Ainda não tenho uma conta · Criar grátis</button>
      <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1"><ShieldCheck className="w-3.5 h-3.5" /> Acesso protegido</div>
    </form>
  </>);
};

const SocialButtons: React.FC<{ onSelect: (provider: string) => void }> = ({ onSelect }) => (
  <div className="grid grid-cols-3 gap-2">
    <button type="button" onClick={() => onSelect('Google')} className="py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-1.5 text-xs font-bold"><Chrome className="w-4 h-4" /> Google</button>
    <button type="button" onClick={() => onSelect('Apple')} className="py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-1.5 text-xs font-bold"><Apple className="w-4 h-4" /> Apple</button>
    <button type="button" onClick={() => onSelect('Facebook')} className="py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-1.5 text-xs font-bold"><Facebook className="w-4 h-4" /> Facebook</button>
  </div>
);
